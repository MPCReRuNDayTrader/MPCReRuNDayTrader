#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class BuzzardBucketDynamicGridByATR : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Auto sets grid lines to a rounded  ATR";
				Name										= "BuzzardBucketDynamicGridByATR";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				ATRint								= 20;
			}
			else if (State == State.Configure)
			{

                AddPlot(Brushes.Yellow, "MyPlot");
            }

        }

        double myvalue = 0;
		double atrValue;
        protected override void OnBarUpdate()
        {
            Value[0] = ATR(ATRint)[0];
            myvalue = Value[0];
			atrValue = Instrument.MasterInstrument.RoundToTickSize(myvalue);
			Draw.TextFixed(this, "ATR", "ATR(" + ATRint.ToString() + "): " + atrValue.ToString(), TextPosition.BottomRight);
        }

        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
			if (chartScale.Properties.HorizontalGridlinesCalculation != YAxisRangeType.Fixed)
		chartScale.Properties.HorizontalGridlinesCalculation = YAxisRangeType.Fixed;
            chartScale.Properties.HorizontalGridlinesInterval = Instrument.MasterInstrument.RoundToTickSize(myvalue);

        }
		#region Properties
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="ATR Period", Description="Numbers of bars used for calculations", Order=1, GroupName="Parameters")]
		public int ATRint
		{ get; set; }
#endregion
		
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private BuzzardBucketDynamicGridByATR[] cacheBuzzardBucketDynamicGridByATR;
		public BuzzardBucketDynamicGridByATR BuzzardBucketDynamicGridByATR(int aTRint)
		{
			return BuzzardBucketDynamicGridByATR(Input, aTRint);
		}

		public BuzzardBucketDynamicGridByATR BuzzardBucketDynamicGridByATR(ISeries<double> input, int aTRint)
		{
			if (cacheBuzzardBucketDynamicGridByATR != null)
				for (int idx = 0; idx < cacheBuzzardBucketDynamicGridByATR.Length; idx++)
					if (cacheBuzzardBucketDynamicGridByATR[idx] != null && cacheBuzzardBucketDynamicGridByATR[idx].ATRint == aTRint && cacheBuzzardBucketDynamicGridByATR[idx].EqualsInput(input))
						return cacheBuzzardBucketDynamicGridByATR[idx];
			return CacheIndicator<BuzzardBucketDynamicGridByATR>(new BuzzardBucketDynamicGridByATR(){ ATRint = aTRint }, input, ref cacheBuzzardBucketDynamicGridByATR);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.BuzzardBucketDynamicGridByATR BuzzardBucketDynamicGridByATR(int aTRint)
		{
			return indicator.BuzzardBucketDynamicGridByATR(Input, aTRint);
		}

		public Indicators.BuzzardBucketDynamicGridByATR BuzzardBucketDynamicGridByATR(ISeries<double> input , int aTRint)
		{
			return indicator.BuzzardBucketDynamicGridByATR(input, aTRint);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.BuzzardBucketDynamicGridByATR BuzzardBucketDynamicGridByATR(int aTRint)
		{
			return indicator.BuzzardBucketDynamicGridByATR(Input, aTRint);
		}

		public Indicators.BuzzardBucketDynamicGridByATR BuzzardBucketDynamicGridByATR(ISeries<double> input , int aTRint)
		{
			return indicator.BuzzardBucketDynamicGridByATR(input, aTRint);
		}
	}
}

#endregion
