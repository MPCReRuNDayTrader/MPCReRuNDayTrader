#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class GannSquareOfNine : Indicator
	{
		private int lineCount0 = 0;
		private int NumberOfLines = 25;
		private string label = "";
		private int i;
		private Brush Color0;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Places lines on chart based on initial price set by user. The lines are calculated from Gann Square principles.";
				Name										= "GannSquareOfNine";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				IsAutoScale									= false;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				BuyLineColor					= Brushes.DarkOliveGreen;
				SellLineColor					= Brushes.Brown;
				InitialPrice					= 3800;
				Line_Size					=1;
				UpTargetLineColor					= Brushes.Teal;
				DownTargetLineColor					= Brushes.Violet;
				Target_Lines_Size					= 1;
	;
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
			double LevelUp=-1.0,LevelDown=-1.0;
						i=1;
						
						lineCount0 		= 0;  	// added 12-10-2021, used for tag name and line limits
						double centerSquare = Math.Floor(Math.Sqrt(InitialPrice))-1;
					    double centerPrice = Math.Pow(centerSquare,2);
						double UpSide = 0;
						double DownSide = 0;
					do
						{
							if(NumberOfLines==25)
							{ 
								label = "A0";							// added 12-10-2021
								if (lineCount0 < NumberOfLines)			// added 12-10-2021
								{
									label +=lineCount0.ToString();		// added 12-10-2021
									//Create the main price line and call MarketPriceLine to draw it
									LevelUp= Math.Pow(centerSquare,2);    
									LevelDown=0; //Kept this from previous persons code because I did not feel like recreating the method parameters ;)
									if(LevelUp > InitialPrice)
										Color0 = BuyLineColor;
									if(LevelUp < InitialPrice)
										Color0 = SellLineColor;
									MakePriceLine(LevelUp,LevelDown, label, Color0);
									
									//Create the up side line for the line just created using the current value of LevelUp var increased by 1.75 points and call MarketPriceLine, then reduce LevelUp back to proper value
									UpSide = (LevelUp + 1.75);
									
									MakeUpLine(UpSide,LevelDown, label, UpTargetLineColor);
									
									
									//Create the Down side line for the line just created using the current value of LevelUp var decreased by 1.75 points and call MarketPriceLine, then increase LevelUp back to proper value
									DownSide = (LevelUp - 1.75);
									MakeDownLine(DownSide,LevelDown, label, DownTargetLineColor);
									LevelUp+=1.75;
									//Now increment centerSquare and lineCount0 to roll through the loop
									centerSquare+=.125;
									lineCount0++;						// added 12-10-2021
								}
							}
							if(lineCount0==25) 
								break;
						}
						while (1==1);
		}
		private void MakePriceLine(double Up, double Down, string labl, Brush  C)
		{	
		//	if(Up>0.0 && Up < MAX_HIGH) 
		//	{
				Draw.HorizontalLine(this, labl+"Main" , IsAutoScale,Up,C,DashStyleHelper.Dash,Line_Size);		// 12-10-2021, used IsAutoScale
		//	}
		//	if(Down>0.0 && Down > MIN_LOW) 
		//	{
		//		Draw.HorizontalLine(this, labl+"down",IsAutoScale,Down,C,DashStyleHelper.Dash,1);  // 12-10-2021, used IsAutoScale
		//	}
		}
		
		private void MakeUpLine(double Up, double Down, string labl, Brush  C)
		{	
		//	if(Up>0.0 && Up < MAX_HIGH) 
		//	{
				Draw.HorizontalLine(this, labl+"upLine" , IsAutoScale,Up,C,DashStyleHelper.DashDotDot,Target_Lines_Size);		// 12-10-2021, used IsAutoScale
		//	}
		//	if(Down>0.0 && Down > MIN_LOW) 
		//	{
		//		Draw.HorizontalLine(this, labl+"down",IsAutoScale,Down,C,DashStyleHelper.Dash,1);  // 12-10-2021, used IsAutoScale
		//	}
		}
		
		private void MakeDownLine(double Up, double Down, string labl, Brush  C)
		{	
		//	if(Up>0.0 && Up < MAX_HIGH) 
		//	{
				Draw.HorizontalLine(this, labl+"downline" , IsAutoScale,Up,C,DashStyleHelper.DashDotDot,Target_Lines_Size);		// 12-10-2021, used IsAutoScale
		//	}
		//	if(Down>0.0 && Down > MIN_LOW) 
		//	{
		//		Draw.HorizontalLine(this, labl+"down",IsAutoScale,Down,C,DashStyleHelper.Dash,1);  // 12-10-2021, used IsAutoScale
		//	}
		}

		#region Properties
		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="BuyLineColor", Description="Sets the color for the Buy Side Lines", Order=1, GroupName="Parameters")]
		public Brush BuyLineColor
		{ get; set; }

		[Browsable(false)]
		public string BuyLineColorSerializable
		{
			get { return Serialize.BrushToString(BuyLineColor); }
			set { BuyLineColor = Serialize.StringToBrush(value); }
		}			

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="SellLineColor", Description="Sets the color for the Sell Lines Color", Order=2, GroupName="Parameters")]
		public Brush SellLineColor
		{ get; set; }

		[Browsable(false)]
		public string SellLineColorSerializable
		{
			get { return Serialize.BrushToString(SellLineColor); }
			set { SellLineColor = Serialize.StringToBrush(value); }
		}			

		[NinjaScriptProperty]
		[Range(3600, double.MaxValue)]
		[Display(Name="InitialPrice", Description="Sets the price to use for line calculations. Use session open, or VWAP, or Last traded price, or any price you desire.", Order=3, GroupName="Parameters")]
		public double InitialPrice
		{ get; set; }
		
			[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Line_Size", Order=3, GroupName="Parameters")]
		public int Line_Size
		{ get; set; }

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="UpTargetLineColor", Order=4, GroupName="Parameters")]
		public Brush UpTargetLineColor
		{ get; set; }

		[Browsable(false)]
		public string UpTargetLineColorSerializable
		{
			get { return Serialize.BrushToString(UpTargetLineColor); }
			set { UpTargetLineColor = Serialize.StringToBrush(value); }
		}			

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="DownTargetLineColor", Order=5, GroupName="Parameters")]
		public Brush DownTargetLineColor
		{ get; set; }

		[Browsable(false)]
		public string DownTargetLineColorSerializable
		{
			get { return Serialize.BrushToString(DownTargetLineColor); }
			set { DownTargetLineColor = Serialize.StringToBrush(value); }
		}			

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Target_Lines_Size", Order=6, GroupName="Parameters")]
		public int Target_Lines_Size
		{ get; set; }
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private GannSquareOfNine[] cacheGannSquareOfNine;
		public GannSquareOfNine GannSquareOfNine(Brush buyLineColor, Brush sellLineColor, double initialPrice, int line_Size, Brush upTargetLineColor, Brush downTargetLineColor, int target_Lines_Size)
		{
			return GannSquareOfNine(Input, buyLineColor, sellLineColor, initialPrice, line_Size, upTargetLineColor, downTargetLineColor, target_Lines_Size);
		}

		public GannSquareOfNine GannSquareOfNine(ISeries<double> input, Brush buyLineColor, Brush sellLineColor, double initialPrice, int line_Size, Brush upTargetLineColor, Brush downTargetLineColor, int target_Lines_Size)
		{
			if (cacheGannSquareOfNine != null)
				for (int idx = 0; idx < cacheGannSquareOfNine.Length; idx++)
					if (cacheGannSquareOfNine[idx] != null && cacheGannSquareOfNine[idx].BuyLineColor == buyLineColor && cacheGannSquareOfNine[idx].SellLineColor == sellLineColor && cacheGannSquareOfNine[idx].InitialPrice == initialPrice && cacheGannSquareOfNine[idx].Line_Size == line_Size && cacheGannSquareOfNine[idx].UpTargetLineColor == upTargetLineColor && cacheGannSquareOfNine[idx].DownTargetLineColor == downTargetLineColor && cacheGannSquareOfNine[idx].Target_Lines_Size == target_Lines_Size && cacheGannSquareOfNine[idx].EqualsInput(input))
						return cacheGannSquareOfNine[idx];
			return CacheIndicator<GannSquareOfNine>(new GannSquareOfNine(){ BuyLineColor = buyLineColor, SellLineColor = sellLineColor, InitialPrice = initialPrice, Line_Size = line_Size, UpTargetLineColor = upTargetLineColor, DownTargetLineColor = downTargetLineColor, Target_Lines_Size = target_Lines_Size }, input, ref cacheGannSquareOfNine);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.GannSquareOfNine GannSquareOfNine(Brush buyLineColor, Brush sellLineColor, double initialPrice, int line_Size, Brush upTargetLineColor, Brush downTargetLineColor, int target_Lines_Size)
		{
			return indicator.GannSquareOfNine(Input, buyLineColor, sellLineColor, initialPrice, line_Size, upTargetLineColor, downTargetLineColor, target_Lines_Size);
		}

		public Indicators.GannSquareOfNine GannSquareOfNine(ISeries<double> input , Brush buyLineColor, Brush sellLineColor, double initialPrice, int line_Size, Brush upTargetLineColor, Brush downTargetLineColor, int target_Lines_Size)
		{
			return indicator.GannSquareOfNine(input, buyLineColor, sellLineColor, initialPrice, line_Size, upTargetLineColor, downTargetLineColor, target_Lines_Size);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.GannSquareOfNine GannSquareOfNine(Brush buyLineColor, Brush sellLineColor, double initialPrice, int line_Size, Brush upTargetLineColor, Brush downTargetLineColor, int target_Lines_Size)
		{
			return indicator.GannSquareOfNine(Input, buyLineColor, sellLineColor, initialPrice, line_Size, upTargetLineColor, downTargetLineColor, target_Lines_Size);
		}

		public Indicators.GannSquareOfNine GannSquareOfNine(ISeries<double> input , Brush buyLineColor, Brush sellLineColor, double initialPrice, int line_Size, Brush upTargetLineColor, Brush downTargetLineColor, int target_Lines_Size)
		{
			return indicator.GannSquareOfNine(input, buyLineColor, sellLineColor, initialPrice, line_Size, upTargetLineColor, downTargetLineColor, target_Lines_Size);
		}
	}
}

#endregion
