#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class RangeBarPivot : Indicator
	{
		private string _myVal; 
		private double _myLow;
		private double _myHigh;
		private double _myClose;
		private double _myRange;
		private double _Pivot;
		private double _R1;
		private double _S1;
		private double _R2;
		private double _S2;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Plots the expected Close as the candle progresses";
				Name										= "RangeBarPivot";
				Calculate									= Calculate.OnPriceChange;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				R1Line					= Brushes.Ivory;
				S1Line					= Brushes.Ivory;
				R2Line					= Brushes.Ivory;
				S2Line					= Brushes.Ivory;
				PivotLine				= Brushes.Ivory;
	
			}
			else if (State == State.Configure)
			{
			}
			
		}


//		protected override void OnMarketDepth(MarketDepthEventArgs marketDepthUpdate)
//		{
			
//		}

		protected override void OnBarUpdate()
		{
			if(BarsPeriod.BarsPeriodType == BarsPeriodType.Volumetric){
				_myRange = BarsPeriod.BaseBarsPeriodValue*TickSize;
			}else{
				_myRange = BarsPeriod.Value*TickSize;
			}
			if(CurrentBar < 1)
				return;
			if(IsFirstTickOfBar){
				
				if(DrawObjects["Pivot"+_myVal] != null)
				RemoveDrawObject("Pivot"+_myVal);
				if(DrawObjects["R1"+_myVal] != null)
				RemoveDrawObject("R1"+_myVal);
				if(DrawObjects["S1"+_myVal] != null)
				RemoveDrawObject("S1"+_myVal);
				if(DrawObjects["R2"+_myVal] != null)
				RemoveDrawObject("R2"+_myVal);
				if(DrawObjects["S2"+_myVal] != null)
				RemoveDrawObject("S2"+_myVal);
				
			_myVal = CurrentBar.ToString();
			}
		//	Draw.Text(this, "ibecool", BarsPeriod.Value.ToString(), 1, High[0]+16*TickSize, Brushes.Aqua);
			
			_myLow = Low[1];
			_myHigh = High[1];
			_myClose =Close[1];
			_Pivot = (_myHigh + _myLow + _myClose)/3;
			_R1 = (_Pivot*2)-_myLow;
			_S1 = (_Pivot*2)-_myHigh;
			_R2 = _Pivot + (_myHigh - _myLow);
			_S2 = _Pivot - (_myHigh - _myLow);
			
			if(_Pivot != null)
			Draw.Line(this, "Pivot" + _myVal, true, 2, _Pivot, 0, _Pivot, PivotLine, DashStyleHelper.Dash, 2);
			
			if(_R1 != null)
			Draw.Line(this, "R1" + _myVal, true, 2, _R1, 0, _R1, R1Line, DashStyleHelper.Dash, 2);
			if(_S1 != null)
			Draw.Line(this, "S1" + _myVal, true, 2, _S1, 0, _S1, S1Line, DashStyleHelper.Dash, 2);
			if(_R2 != null)
			Draw.Line(this, "R2" + _myVal, true, 2, _R2, 0, _R2, R2Line, DashStyleHelper.Dash, 2);
			if(_S2 != null)
			Draw.Line(this, "S2" + _myVal, true, 2, _S2, 0, _S2, S2Line, DashStyleHelper.Dash, 2);
		
			
			
			
		}	
		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="PivotLine", Description="Color of the Pivot Line", Order=1, GroupName="Parameters")]
		public Brush PivotLine
		{ get; set; }

		[Browsable(false)]
		public string PivotLineSerializable
		{
			get { return Serialize.BrushToString(PivotLine); }
			set { PivotLine = Serialize.StringToBrush(value); }
		}			
		
		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="R1Line", Description="R1 Line Color", Order=2, GroupName="Parameters")]
		public Brush R1Line
		{ get; set; }

		[Browsable(false)]
		public string R1LineSerializable
		{
			get { return Serialize.BrushToString(R1Line); }
			set { R1Line = Serialize.StringToBrush(value); }
		}	
		
		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="R2Line", Description="R2 Line Color", Order=3, GroupName="Parameters")]
		public Brush R2Line
		{ get; set; }

		[Browsable(false)]
		public string R2LineSerializable
		{
			get { return Serialize.BrushToString(R2Line); }
			set { R2Line = Serialize.StringToBrush(value); }
		}			

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="S1Line", Description="Color of the S1 Line", Order=4, GroupName="Parameters")]
		public Brush S1Line
		{ get; set; }

		[Browsable(false)]
		public string S1LineSerializable
		{
			get { return Serialize.BrushToString(S1Line); }
			set { S1Line = Serialize.StringToBrush(value); }
		}			
		
		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="S2Line", Description="Color of the S2 Line", Order=5, GroupName="Parameters")]
		public Brush S2Line
		{ get; set; }

		[Browsable(false)]
		public string S2LineSerializable
		{
			get { return Serialize.BrushToString(S2Line); }
			set { S2Line = Serialize.StringToBrush(value); }
		}			
		
		


	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private RangeBarPivot[] cacheRangeBarPivot;
		public RangeBarPivot RangeBarPivot(Brush pivotLine, Brush r1Line, Brush r2Line, Brush s1Line, Brush s2Line)
		{
			return RangeBarPivot(Input, pivotLine, r1Line, r2Line, s1Line, s2Line);
		}

		public RangeBarPivot RangeBarPivot(ISeries<double> input, Brush pivotLine, Brush r1Line, Brush r2Line, Brush s1Line, Brush s2Line)
		{
			if (cacheRangeBarPivot != null)
				for (int idx = 0; idx < cacheRangeBarPivot.Length; idx++)
					if (cacheRangeBarPivot[idx] != null && cacheRangeBarPivot[idx].PivotLine == pivotLine && cacheRangeBarPivot[idx].R1Line == r1Line && cacheRangeBarPivot[idx].R2Line == r2Line && cacheRangeBarPivot[idx].S1Line == s1Line && cacheRangeBarPivot[idx].S2Line == s2Line && cacheRangeBarPivot[idx].EqualsInput(input))
						return cacheRangeBarPivot[idx];
			return CacheIndicator<RangeBarPivot>(new RangeBarPivot(){ PivotLine = pivotLine, R1Line = r1Line, R2Line = r2Line, S1Line = s1Line, S2Line = s2Line }, input, ref cacheRangeBarPivot);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.RangeBarPivot RangeBarPivot(Brush pivotLine, Brush r1Line, Brush r2Line, Brush s1Line, Brush s2Line)
		{
			return indicator.RangeBarPivot(Input, pivotLine, r1Line, r2Line, s1Line, s2Line);
		}

		public Indicators.RangeBarPivot RangeBarPivot(ISeries<double> input , Brush pivotLine, Brush r1Line, Brush r2Line, Brush s1Line, Brush s2Line)
		{
			return indicator.RangeBarPivot(input, pivotLine, r1Line, r2Line, s1Line, s2Line);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.RangeBarPivot RangeBarPivot(Brush pivotLine, Brush r1Line, Brush r2Line, Brush s1Line, Brush s2Line)
		{
			return indicator.RangeBarPivot(Input, pivotLine, r1Line, r2Line, s1Line, s2Line);
		}

		public Indicators.RangeBarPivot RangeBarPivot(ISeries<double> input , Brush pivotLine, Brush r1Line, Brush r2Line, Brush s1Line, Brush s2Line)
		{
			return indicator.RangeBarPivot(input, pivotLine, r1Line, r2Line, s1Line, s2Line);
		}
	}
}

#endregion
