#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class RangeForecast : Indicator
	{
		private string _myVal; 
		private double _myLow;
		private double _myHigh;
		private double _myRange;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Plots the expected Close as the candle progresses";
				Name										= "RangeForecast";
				Calculate									= Calculate.OnPriceChange;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				HighLine					= Brushes.Ivory;
				LowLine					= Brushes.Ivory;
	
			}
			else if (State == State.Configure)
			{
			}
		}

//		protected override void OnMarketDepth(MarketDepthEventArgs marketDepthUpdate)
//		{
			
//		}

		protected override void OnBarUpdate()
		{
			_myRange = BarsPeriod.Value*TickSize;
			if(CurrentBar < 1)
				return;
			if(IsFirstTickOfBar){
				
				if(DrawObjects["low"+_myVal] != null)
				RemoveDrawObject("low"+_myVal);
				if(DrawObjects["high"+_myVal] != null)
				RemoveDrawObject("high"+_myVal);
				
			_myVal = CurrentBar.ToString();
			}
		//	Draw.Text(this, "ibecool", BarsPeriod.Value.ToString(), 1, High[0]+16*TickSize, Brushes.Aqua);
			
			_myLow = Low[0];
			_myHigh = High[0];
			if(_myLow != null)
			Draw.Line(this, "low" + _myVal, true, 1, High[0] - _myRange, -1, High[0] - _myRange, LowLine, DashStyleHelper.Dash, 2);
			
			if(_myHigh != null)
			Draw.Line(this, "high" + _myVal, true, 1, Low[0] + _myRange, -1, Low[0] + _myRange, HighLine, DashStyleHelper.Dash, 2);
			
			
			
			
		}		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="HighLine", Description="High Side Line Color", Order=1, GroupName="Parameters")]
		public Brush HighLine
		{ get; set; }

		[Browsable(false)]
		public string HighLineSerializable
		{
			get { return Serialize.BrushToString(HighLine); }
			set { HighLine = Serialize.StringToBrush(value); }
		}			

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="LowLine", Description="Color of the Low Side Line", Order=2, GroupName="Parameters")]
		public Brush LowLine
		{ get; set; }

		[Browsable(false)]
		public string LowLineSerializable
		{
			get { return Serialize.BrushToString(LowLine); }
			set { LowLine = Serialize.StringToBrush(value); }
		}			



	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private RangeForecast[] cacheRangeForecast;
		public RangeForecast RangeForecast(Brush highLine, Brush lowLine)
		{
			return RangeForecast(Input, highLine, lowLine);
		}

		public RangeForecast RangeForecast(ISeries<double> input, Brush highLine, Brush lowLine)
		{
			if (cacheRangeForecast != null)
				for (int idx = 0; idx < cacheRangeForecast.Length; idx++)
					if (cacheRangeForecast[idx] != null && cacheRangeForecast[idx].HighLine == highLine && cacheRangeForecast[idx].LowLine == lowLine && cacheRangeForecast[idx].EqualsInput(input))
						return cacheRangeForecast[idx];
			return CacheIndicator<RangeForecast>(new RangeForecast(){ HighLine = highLine, LowLine = lowLine }, input, ref cacheRangeForecast);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.RangeForecast RangeForecast(Brush highLine, Brush lowLine)
		{
			return indicator.RangeForecast(Input, highLine, lowLine);
		}

		public Indicators.RangeForecast RangeForecast(ISeries<double> input , Brush highLine, Brush lowLine)
		{
			return indicator.RangeForecast(input, highLine, lowLine);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.RangeForecast RangeForecast(Brush highLine, Brush lowLine)
		{
			return indicator.RangeForecast(Input, highLine, lowLine);
		}

		public Indicators.RangeForecast RangeForecast(ISeries<double> input , Brush highLine, Brush lowLine)
		{
			return indicator.RangeForecast(input, highLine, lowLine);
		}
	}
}

#endregion
